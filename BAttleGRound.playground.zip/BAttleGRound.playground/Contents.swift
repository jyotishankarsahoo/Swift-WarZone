//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
str

func getTheLinePrinted(str : String)
{
    print("get the value printed \(str)")
}

getTheLinePrinted("jyoti")
var pArray = ["1","2vcvvcvc","3","4"]
for i in pArray
{
    print(i)
}

func getTheTuppleOutPut() -> (Int,String)
{
    let tupple = (1,"me")
    return tupple
}

print(getTheTuppleOutPut().1)

let pFloatingNumber : Float32 = 4.0

let width = 45

let desc = "Table width is :"

var completeDesc = desc + String (width)


let chapter = 2.0
let name = "Swift"

var welcomeString = "welcome to \(name) chapter \(chapter)"

var array = [1,2,34]
array[2]
array += [3]


var dict = ["key-1":"jyoti" , 1 : "shankar"]
dict["key-1"]
dict[1]
dict.updateValue("sahoo", forKey: 1)

var emptyArray = [String]()
var emptyDictionary = [String : Float32]()

let individualScore = [2,4,32,45,76]
var totalScore = 0
for score in individualScore
{
    if score > 10
    {
        totalScore += 3
    }else
    {
        totalScore -= 1
    }
}
print("\(totalScore)")



var optionalString : String? = nil

var greeting = "Hello"

if let name = optionalString
{
    print("hello \(name)")
}else
{
    print("WTF name is nil")
}

let nickName : String? = "xyz"
let fullName = "Abc Def"
let greetingText = "Hi \(nickName ?? fullName)"




